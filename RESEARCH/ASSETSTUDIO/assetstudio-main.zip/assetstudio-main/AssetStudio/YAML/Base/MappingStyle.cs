namespace AssetStudio
{
	/// <summary>
	/// Specifies the style of a mapping.
	/// </summary>
	public enum MappingStyle
	{
		/// <summary>
		/// The block mapping style.
		/// </summary>
		Block,

		/// <summary>
		/// The flow mapping style.
		/// </summary>
		Flow
	}
}
